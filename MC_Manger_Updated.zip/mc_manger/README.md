# MC Manger (Phase 1 foundation)
Offline Bedrock world manager. See docs/compatibility.md for exactly what exists.

    python3 tools/make_fixture.py
    ./tools/apply_android_overlay.sh
    flutter pub get && flutter analyze && flutter test && flutter build apk --debug


## Added in this update

- **level.dat editor** for selected top-level fields. Saves go through `WorldMutationService`, which creates and verifies a SHA-256-manifest backup before replacing `level.dat`; unknown NBT fields are preserved.
- **.mcworld export** builds a ZIP with world-relative paths and offers Android's share sheet so it can be opened/imported by Minecraft. The source world is not modified.
- **DB record draft editor** can edit raw value bytes and preview NBT, but only saves a local draft JSON. **It cannot apply changes to the game yet**: the project still needs a MANIFEST-aware Bedrock LevelDB writer; writing raw SSTable/log bytes is unsafe.
- **Offline block/item icon catalog** with searchable common Minecraft IDs. These are emoji/color approximations, not Mojang sprite textures.

Close Minecraft before editing/exporting. Backups are labelled `unverified_snapshot`: the app cannot detect live writes by Minecraft. Build and device verification still need to be run with Flutter/Android SDK and a copy of a real Bedrock 1.26 world.
